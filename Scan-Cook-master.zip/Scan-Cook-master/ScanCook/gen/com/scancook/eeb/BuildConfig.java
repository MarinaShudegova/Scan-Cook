/** Automatically generated file. DO NOT MODIFY */
package com.scancook.eeb;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}